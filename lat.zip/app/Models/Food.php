<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Food extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'foods';

    protected $fillable = [
        'category_id',
        'code',
        'barcode',
        'hsn_code',
        'name',
        'price',
        'cost_price',
        'mrp',
        'stock',
        'tax_rate',
        'is_veg',
        'is_active',
        'image',
        'description',
    ];

    protected function casts(): array
    {
        return [
            'price' => 'decimal:2',
            'cost_price' => 'decimal:2',
            'mrp' => 'decimal:2',
            'stock' => 'decimal:3',
            'tax_rate' => 'decimal:2',
            'is_veg' => 'boolean',
            'is_active' => 'boolean',
        ];
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function ingredients(): BelongsToMany
    {
        return $this->belongsToMany(InventoryItem::class, 'food_ingredients', 'food_id', 'inventory_item_id')
            ->withPivot('quantity')
            ->withTimestamps();
    }

    public function combos(): BelongsToMany
    {
        return $this->belongsToMany(Combo::class, 'combo_items')
            ->withPivot('quantity')
            ->withTimestamps();
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeVeg($query)
    {
        return $query->where('is_veg', true);
    }

    public function scopeNonVeg($query)
    {
        return $query->where('is_veg', false);
    }
}
